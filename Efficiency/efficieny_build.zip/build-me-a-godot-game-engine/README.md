# Quadtree Collision Demo

Godot 4 project demonstrating a quadtree broad-phase collision pass versus a basic all-pairs math scan.

## Run

Open this folder in Godot 4 and run `res://scenes/Main.tscn`.

## Controls

- Move the green player with `W`, `A`, `S`, and `D`.
- Toggle pause with `P` or the `Paused (P)` checkbox.
- Use the right-side menu to switch between `Quadtree` and `Basic math scan`.
- Raise `Forced clock` to run more simulation/collision ticks per second.
- Raise `Enemy burst rate` to make each enemy fire radial volleys more often.
- Raise `Bullet speed` to make volley bullets travel faster.
- The metrics panel shows only the active collision method, so game performance reflects the selected mode only.
- The tabbed display below the map estimates CPU usage from the selected collision method and resets that method's CPU average whenever you switch modes.

The map is a 40x40 grid with six fixed wall segments. Red emitters fire 10-bullet radial bursts with a 10,000 bullet cap. Bullets, walls, enemies, and the player are evaluated with custom GDScript collision math so the comparison is visible in the counters.
